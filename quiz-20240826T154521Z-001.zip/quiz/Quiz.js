function botao(){
    var select1 = document.getElementById('select1').value
    var select2 = document.getElementById('select2').value
    var select3 = document.getElementById('select3').value
    var resultado = document.getElementById('MostrarResultado')
    
    var slc = Number(select1) + Number(select2) + Number(select3)

    if(slc = 3){

    }

    resultado.value = slc

}